# -*- coding: utf-8 -*-
from . import Blueprint

app = Blueprint("admission_rules", __name__, url_prefix="/admission_rules")
