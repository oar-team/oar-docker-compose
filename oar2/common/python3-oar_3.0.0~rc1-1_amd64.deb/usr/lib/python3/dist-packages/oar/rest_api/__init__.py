# -*- coding: utf-8 -*-
API_VERSION = "2.0.0.dev0"
