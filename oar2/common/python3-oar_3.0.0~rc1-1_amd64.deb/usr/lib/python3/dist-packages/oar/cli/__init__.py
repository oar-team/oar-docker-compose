# -*- coding: utf-8 -*-
"""
    oar.cli
    ~~~~~~~

    OAR Command line interface

"""
