# -*- coding: utf-8 -*-
__version__ = "3.0.0.dev4"
VERSION = __version__
