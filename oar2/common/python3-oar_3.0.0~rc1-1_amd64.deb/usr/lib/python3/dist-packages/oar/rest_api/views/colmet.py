# -*- coding: utf-8 -*-
from . import Blueprint

app = Blueprint("colmet", __name__, url_prefix="/colmet")
