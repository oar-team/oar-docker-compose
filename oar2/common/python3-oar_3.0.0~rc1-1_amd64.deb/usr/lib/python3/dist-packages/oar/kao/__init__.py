# coding: utf-8
"""
Module handling the scheduling in OAR.
It defined both schedulers, and scheduling data structures.
"""
